#include <cstdlib>
#include <time.h>
#include <iostream>
#include <string.h>
using namespace std;

#include "Restaurant.h"
#include "..\Events\ArrivalEvent.h"
#include"..\Generic_DS\UnsortedList.h"
#include"..\Generic_DS\SortedList.h"
#include"..\Generic_DS\PriorityData.h"

Restaurant::Restaurant() 
{
	pGUI = NULL;
	injuredCount = 0;
}
void Restaurant::Add_Order(Order* o )
{
	if (o->GetType()== TYPE_NRM )
	{
		int size = W_Order_Normal.getLength();
		W_Order_Normal.insert(size, o) ;
	}
	if (o->GetType()== TYPE_VGAN )
	{
		W_Order_Vegan.enqueue(o);

	}
	if(o->GetType()== TYPE_VIP)
	{
		float temp, money, size, arrivalTime;
		money = o->getTotalMoney();
		size = o->getSize();
		arrivalTime = o->getArrTime();
		temp = ( ( money - size ) / size ) - ( arrivalTime * 0.5 );
		int priority = ceil ( temp );

		PriorityData<Order*> pop (o , priority);
		W_Order_VIP.insertSortedDescendingly(pop);
	}
}
void Restaurant::Add_OrderVip(PriorityData<Order*> o)
{
	W_Order_VIP.insertSortedDescendingly(o);
}
void Restaurant::LoadingFunction(ifstream & input) // note that we passed the ifstream by & (why?)
{
	int N,G,V;
	int SN,SG,SV;
	int BN,BG,BV;
	int AutoP;
	int M;

	ORD_TYPE OrType;

	if (input.is_open())
	{
		input>>N>>G>>V;
		input>>SN>>SG>>SV;
		input>>breakNumber>>BN>>BG>>BV;
		input>>AutoP;
		input>>M;

		int cookID = 1; 

		for(int ID=1;ID<=V;ID++)
		{
			OrType = TYPE_VIP;
			Cook* VipCook=new Cook();
			VipCook->setType(OrType);
			VipCook->setBreakDuration(BV);
			VipCook->setID(cookID);
			VipCook->setSpeed(SV);

			//Av_cooks_VIP.enqueue(VipCook);             // ---> MOHAMED's PART
			cookID++;
		}
		for(int ID=1;ID<=N;ID++)
		{
			OrType = TYPE_NRM;
			Cook* NormalCook=new Cook();  // variables tet3emel fe class cook we ne3mel constructor keda
			NormalCook->setType(OrType);
			NormalCook->setBreakDuration(BN);
			NormalCook->setID(cookID);
			NormalCook->setSpeed(SN);

			//AV_Cooks_Normal.enqueue(NormalCook);       // ---> MOHAMED's PART
			cookID++;
		}
		for(int ID=1;ID<=G;ID++)
		{
			OrType = TYPE_VGAN;
			Cook* VeganCook=new Cook();
			VeganCook->setType(OrType);
			VeganCook->setBreakDuration(BG);
			VeganCook->setID(cookID);
			VeganCook->setSpeed(SG);

			//AV_Cooks_vegan.enqueue(VeganCook);         // ---> MOHAMED's PART 
			cookID++;
		}
		
		/////////////////////////////////////////
		
		char temp,orderType;
		int one ,two , three,four;

		for(int l=1; l<=M; l++)
		{
			input >> temp;

			if(temp == 'R')
			{
				input >> orderType >> one >> two >> three >> four;

				if(orderType=='N')
					OrType=TYPE_NRM;
				if(orderType=='G')
					OrType=TYPE_VGAN;
				if(orderType=='V')
					OrType=TYPE_VIP;


				Event* event= new ArrivalEvent((ORD_TYPE)OrType,one,two,three,four); // variables tet7at fel class we ne3melhom fe constructor
				EventsQueue.enqueue(event);
			}
			if(temp== 'X')
			{
				input >> one >> two;

				Event* event= new Cancellation(one,two);
				EventsQueue.enqueue(event);
			}
			if(temp=='P')
			{
				input >> one >> two >> three;

				Event* event= new Promotion (one,two,three);
				EventsQueue.enqueue(event);
			}
		}
		pGUI->PrintMessage("loaded.......click to continue");
		pGUI->waitForClick();
		input.close();
	}
	else
	{pGUI->PrintMessage ("Unable to open file.......click to continue");
	
	pGUI->waitForClick();

	}
}




void Restaurant::RunSimulation()
{
	pGUI = new GUI;
	PROG_MODE	mode = pGUI->getGUIMode();

	switch (mode)	//Add a function for each mode in next phases
	{
	case MODE_INTR:
		Simple_simulator();
	case MODE_STEP:
		break;
	case MODE_SLNT:
		break;
	//case MODE_DEMO:
		

	};

}


//////////////////////////////////  Event handling functions   /////////////////////////////

//Executes ALL events that should take place at current timestep
void Restaurant::ExecuteEvents(int CurrentTimeStep)
{
	Event *pE;
	while( EventsQueue.peekFront(pE) )	//as long as there are more events
	{
		if(pE->getEventTime() != CurrentTimeStep )	//no more events at current timestep
			return;

		pE->Execute(this);
		EventsQueue.dequeue(pE);	//remove event from the queue
		delete pE;		//deallocate event object from memory
	}

}


Restaurant::~Restaurant()
{
	if (pGUI)
		delete pGUI;
}
bool Restaurant::getEntryNormal( int position, Order* & p, int & c )
{

	W_Order_Normal.getEntry(position, p);
	c = W_Order_Normal.getLength();
	return true;
}

bool Restaurant::removeNormal(int i)
{
	W_Order_Normal.remove(i);
	return true;
}

void Restaurant :: addAvailableCook(Cook* avCook)
{
	int cookProductivity = avCook ->getSpeed() - avCook ->getBreakDuration();
	PriorityData<Cook*> cookToAdd ( avCook, cookProductivity );

	if ( avCook ->getStatus() == TYPE_VIP )
	{
		Av_cooks_VIP.insertSortedDescendingly(cookToAdd);
	}
	else if ( avCook ->getStatus() == TYPE_NRM )
	{
		AV_Cooks_Normal.insertSortedDescendingly(cookToAdd);
	}
	else if ( avCook ->getStatus() == TYPE_VGAN )
	{
		AV_Cooks_vegan.insertSortedDescendingly(cookToAdd);
	}
}

int Restaurant :: getBreakNumber () const
{
	return breakNumber;
}

int Restaurant :: getRestPeriod () const
{
	return restPeriod;
}

int Restaurant :: getInjuredCount () const
{
	return injuredCount;
}

float Restaurant :: getInjProp () const
{
	return injProp;
}
int Restaurant::getAutoP() const
{
	return autoP;
}
int Restaurant::getVIP_WT() const
{
	return VIP_WT;
}
int Restaurant::getUrgentCount() const
{
	return urgentCount;
}
int Restaurant::getPromotionCount() const
{
	return promotionCount;
}

bool Restaurant :: assignCook( Cook* cook, Order* order, int currentTimestep )
{
	if ( order ->getSize() > getBreakNumber() - cook ->getFinishedDishesCount() )
	{
		return false;
	}
	else if ( order ->getSize() <= getBreakNumber() - cook ->getFinishedDishesCount() )
	{
		//Removal of cook from the list of availables

		if ( cook ->getStatus() == AVAILABLE )   // Only remove from the list of availables if the cook assigned was previously available, not on break or in rest
		{
			if ( cook ->GetType() == TYPE_VIP )
			{
				Av_cooks_VIP.remove(cook);
			}
			else if ( cook ->GetType() == TYPE_NRM )
			{
				AV_Cooks_Normal.remove(cook);
			}
			else if ( cook ->GetType() == TYPE_VGAN )
			{
				AV_Cooks_vegan.remove(cook);
			}

		}
		//Necessary changes in corresponding cook and order

		cook ->setStatus(BUSY);
		cook ->setAssignedOrder(order);
		cook ->setFinishedDishesCount( cook ->getFinishedDishesCount() + order ->getSize() );
		servicedOrders(order,currentTimestep); //NOTE:zawedt l timestep ka parameter

		//Adding cook to list of busy cooks

		float temp = ( order ->getSize() / cook ->getSpeed() ) + currentTimestep;
		int orderFinishtime = ceil ( temp );
		PriorityData<Cook*> busyCook ( cook, orderFinishtime );
		Busy_Cooks.insertSortedAscendingly(busyCook);

		return true;
	}
}

void Restaurant :: checkBusyCooks ( int currentTimestep )
{
	PriorityData<Cook*> cookPriorityData;
	Busy_Cooks.getEntry( 0, cookPriorityData );

	while ( cookPriorityData.getPriority() == currentTimestep )
	{
		//General changes when cook finishes order

		Cook* cook = cookPriorityData.getData();
		Busy_Cooks.remove(cook);
		finishedOrders( cook ->getAssignedOrder(), currentTimestep );
		cook ->setAssignedOrder(nullptr);

		if ( cook ->getFinishedDishesCount() == getBreakNumber() )   // when it is time for the cook's break whether he/she is injured or not
		{
			//General changes when cook takes a break

			cook ->setFinishedDishesCount(0);
			cook ->setStatus(ON_BREAK);

			//Further changes if he/she was injured

			if ( cook ->getInjuredThisTime() == true )
			{
				cook ->setSpeed ( cook ->getSpeed() * 2 );
				cook ->setInjuredThisTime (false);
			}

			//Adding cook to list of on break cooks

			int breakFinishTime = currentTimestep + cook ->getBreakDuration();
			PriorityData<Cook*> onBreakCook ( cook, breakFinishTime );
			On_Break_Cooks.insertSortedAscendingly( onBreakCook );
		}
		else if ( cook ->getFinishedDishesCount() < getBreakNumber() && cook ->getInjuredThisTime() == false )   // if the cook is not injured and it is not his break time
		{
			// Add cook to list of availables

			cook ->setStatus(AVAILABLE);
			addAvailableCook(cook);
		}
		else if ( cook ->getFinishedDishesCount() < getBreakNumber() && cook ->getInjuredThisTime() == true )   // if it is not the cook's break time but he is injured
		{
			// changes after injured finishes his order

			cook ->setInjuredThisTime (false);
			cook ->setSpeed ( cook ->getSpeed() * 2 );
			cook ->setStatus (IN_REST);

			// Adding cook to list of in rest cooks

			int restFinishTime = currentTimestep + restPeriod;
			PriorityData<Cook*> InRestCook ( cook, restFinishTime );
			In_Rest_Cooks.insertSortedAscendingly( InRestCook );
		}

		Busy_Cooks.getEntry( 0, cookPriorityData );
	}
}

void Restaurant :: finishedOrders ( Order* order, int currentTimestep )
{
	// change order data members accordingly

	order ->setServiceTime ( currentTimestep - order ->getArrTime() - order ->getWaitTime() );
	order ->updateFinishTime();
	order ->setStatus (DONE);

	// finding position of order to remove it from list of in-service orders

	Order* dummyOrder;
	bool found = false;
	int i = 0;
	
	while ( i < In_service.getLength() && !found )
	{
		In_service.getEntry ( i, dummyOrder );

		if ( dummyOrder == order )
		{
			In_service.remove(i);
			found = true;
		}

		i++;
	}

	// Add order to queue of finished orders

	finished.enqueue(order);
}

void Restaurant :: injureCook ()
{
	//Generating random probability

	float n = rand() % 101;
	float R = n / 100;

	if ( R <= injProp )
	{
		//Making first busy cook injured ( MUST BE CALLED AFTER REMOVING COOKS WHO FINISHED THEIR ORDERS (i.e after checkBusyCooks) )

		PriorityData<Cook*> injuredCook;
		Busy_Cooks.getEntry( 0, injuredCook );

		injuredCook.getData() ->setInjuredThisTime(true);  // injuring cook
		if ( injuredCook.getData() ->getInjuredBefore() == false ) //counting only if it was the first time for the cook to get injured, as a cook can get injured more than once
		{
			injuredCount++;
			injuredCook.getData() ->setInjuredBefore(true);
		}

		//removing cook, making necessary changes due to injury then re-positioning him in the list

		Busy_Cooks.remove( injuredCook.getData() );
		injuredCook.setPriority ( injuredCook.getPriority() * 2 );
		injuredCook.getData() ->setSpeed( injuredCook.getData()->getSpeed() * 0.5 );
		Busy_Cooks.insertSortedAscendingly( injuredCook );
	}
}

void Restaurant :: checkcooksInBreakAndRest ( int currentTimestep )
{
	// Checking on break cooks

	PriorityData<Cook*> cookPriorityData1;
	On_Break_Cooks.getEntry ( 0, cookPriorityData1 );

	while ( cookPriorityData1.getPriority() == currentTimestep )  // his break has finished
	{
		// Remove him from list of on break cooks

		Cook* cook = cookPriorityData1.getData();
		On_Break_Cooks.remove(cook);

		// General changes for this type of cook

		cook ->setStatus ( AVAILABLE );

		// Further changes if this cook was assigned in rest before

		if ( cook ->getAssignedInRest() == true )
		{
			cook ->setSpeed ( cook ->getSpeed() * 2 );
			cook ->setAssignedInRest ( false );
		}

		// Adding cook to list of avaialables

		addAvailableCook ( cook );

		On_Break_Cooks.getEntry ( 0, cookPriorityData1 );
	}

	//-----------------------------------------------------

	// checking on cooks in rest

	PriorityData<Cook*> cookPriorityData2;
	In_Rest_Cooks.getEntry ( 0, cookPriorityData2 );

	while ( cookPriorityData2.getPriority() == currentTimestep )  // his resing period is over
	{
		// Removing cook from list of cooks taking rest

		Cook* cook = cookPriorityData2.getData();
		In_Rest_Cooks.remove(cook);

		// Necessary changes in this type of cook & adding him to list of availables

		cook ->setStatus ( AVAILABLE );
		addAvailableCook ( cook );

		In_Rest_Cooks.getEntry ( 0, cookPriorityData2 );
	}
}

bool Restaurant :: cooksOnBreakAlternative ( Order* urgentOrder, int currentTimestep )  //MUST BE CALLED AFTER REMOVING COOKS WHO FINISHED THEIR BREAK ( i.e. after checkcooksInBreakAndRest )
{                                                                                       //so, the cook assigned has not finished his break yet
	PriorityData<Cook*> cookPriorityData;                                               //if he was assigned in rest, his speed will not go back to normal yet because he has not had a full break (or rest before) yet
	bool cookFound = false;

	// Searching for a VIP cook in the list

	int i1 = 0;

	while ( i1 < Busy_Cooks.getLength() && !cookFound )
	{
		Busy_Cooks.getEntry ( i1, cookPriorityData );

		if ( cookPriorityData.getData() ->GetType() == TYPE_VIP )
		{
			cookFound = true;
		}

		i1++;
	}

	// Searching for a normal one if a VIP one is not found

	int i2 = 0;

	while ( i2 < Busy_Cooks.getLength() && !cookFound )
	{
		Busy_Cooks.getEntry ( i2, cookPriorityData );

		if ( cookPriorityData.getData() ->GetType() == TYPE_NRM )
		{
			cookFound = true;
		}

		i2++;
	}

	// Searching for a vegan one if neither VIP nor normal was found

	int i3 = 0;

	while ( i3 < Busy_Cooks.getLength() && !cookFound )
	{
		Busy_Cooks.getEntry ( i3, cookPriorityData );

		if ( cookPriorityData.getData() ->GetType() == TYPE_VGAN )
		{
			cookFound = true;
		}

		i3++;
	}

	if ( cookFound == true )  //if a suitable cook was found
	{
		Busy_Cooks.remove( cookPriorityData.getData() );                            //Removal 

		assignCook ( cookPriorityData.getData(), urgentOrder, currentTimestep );    //Assignment

		return true;      //A cook from this list was assigned
	}

	return false; //the list was empty so no cook was assigned
}

bool Restaurant :: cooksInRestAlternative ( Order* urgentOrder, int currentTimestep )
{
	PriorityData<Cook*> cookPriorityData;                                              
	bool cookFound = false;

	// Searching for a VIP cook in the list

	int i1 = 0;

	while ( i1 < In_Rest_Cooks.getLength() && !cookFound )
	{
		In_Rest_Cooks.getEntry ( i1, cookPriorityData );

		if ( cookPriorityData.getData() ->GetType() == TYPE_VIP )
		{
			cookFound = true;
		}

		i1++;
	}

	// Searching for a normal one if a VIP one is not found

	int i2 = 0;

	while ( i2 < In_Rest_Cooks.getLength() && !cookFound )
	{
		In_Rest_Cooks.getEntry ( i2, cookPriorityData );

		if ( cookPriorityData.getData() ->GetType() == TYPE_NRM )
		{
			cookFound = true;
		}
		
		i2++;
	}

	// Searching for a vegan one if neither VIP nor normal was found

	int i3 = 0;

	while ( i3 < In_Rest_Cooks.getLength() && !cookFound )
	{
		In_Rest_Cooks.getEntry ( i3, cookPriorityData );

		if ( cookPriorityData.getData() ->GetType() == TYPE_VGAN )
		{
			cookFound = true;
		}

		i3++;
	}

	if ( cookFound == true )  //if a suitable cook was found
	{
		In_Rest_Cooks.remove( cookPriorityData.getData() );                                          //Removal

		cookPriorityData.getData() ->setAssignedInRest (true);                                       //changing data of injured cook was did not take suitable rest (did not complete it)
		cookPriorityData.getData() ->setSpeed ( cookPriorityData.getData() ->getSpeed() * 0.5 );

		assignCook ( cookPriorityData.getData(), urgentOrder, currentTimestep );                     // Assignment

		return true;       //A cook from this list was assigned
	}

	return false; //the list was empty so no cook was assigned
}

void Restaurant::checkUrgentOrders()
{
	if (W_Order_VIP.isEmpty())
		return;


	PriorityData<Order*> urgent;
	int i = 0;

	while (i < W_Order_VIP.getLength())
	{
		W_Order_VIP.getEntry(i, urgent);
		if (urgent.getData()->getWaitTime() >= VIP_WT)
		{
			W_Order_VIP.remove(urgent.getData());
			W_Order_Urgent.enqueue(urgent.getData());

			urgentCount++;
		}
		i++;
	}
}
void Restaurant::checkAutoPromotion()
{
	if (W_Order_Normal.isEmpty())
		return;

	Order* order;
	int i = 0;
	while (i < W_Order_Normal.getLength())
	{
		W_Order_Normal.getEntry(i, order);
		if (order->getWaitTime() >= autoP)
		{
			W_Order_Normal.remove(i);
			order->setType(TYPE_VIP);
			Add_Order(order);
			promotionCount++;
		}
		i++;
	}
}
void Restaurant::serviceVipOrder(int timeStep)
{
	while (W_Order_VIP.isEmpty())
		return;

	int i = 0;
	int c = 0;
	int l = W_Order_VIP.getLength();
	while (i < l)
	{

		bool found = false;

		PriorityData<Order*> pOrd;
		PriorityData<Cook*> pCook;
		W_Order_VIP.getEntry(c, pOrd);

		//assigning it to a VIP cook
		int v = 0;
		while (v < Av_cooks_VIP.getLength() && found == false)
		{
			Av_cooks_VIP.getEntry(v, pCook);
			found = assignCook(pCook.getData(), pOrd.getData(), timeStep);
			v++;
		}


		//assigning it to a normal cook if VIP cook not found
		int n = 0;
		while (n < AV_Cooks_Normal.getLength() && found == false)
		{
			AV_Cooks_Normal.getEntry(n, pCook);
			found = assignCook(pCook.getData(), pOrd.getData(), timeStep);
			n++;
		}


		//assigning it to a vegan cook if neither VIP nor normal cook is found
		int g = 0;
		while (g < AV_Cooks_vegan.getLength() && found == false)
		{
			AV_Cooks_vegan.getEntry(g, pCook);
			found = assignCook(pCook.getData(), pOrd.getData(), timeStep);
			g++;
		}

		//if it wasn't assigned to a cook go to next order
		if (found == false)
		{
			c++;
		}

		i++;
	}
}


void Restaurant::serviceVeganOrder(int timeStep)
{
	while (!W_Order_Vegan.isEmpty())
		return;

	int i = 0;
	int c = 0;
	W_Order_Vegan.toArray(c);

	while (i < c)
	{

		bool found = false;
		Order* pOrd;
		PriorityData<Cook*> pCook;
		W_Order_Vegan.peekFront(pOrd);

		int g = 0;
		while (g < AV_Cooks_vegan.getLength() && found == false)
		{
			AV_Cooks_vegan.getEntry(g, pCook);
			found = assignCook(pCook.getData(), pOrd, timeStep);
			g++;
		}

		i++;
	}

}
void Restaurant::serviceNormalOrder(int timeStep)
{
	while (W_Order_Normal.isEmpty())
		return;

	int i = 0;
	int c = 0;
	int l = W_Order_Normal.getLength();
	while (i < l)
	{


		bool found = false;

		Order* pOrd;
		PriorityData<Cook*> pCook;
		W_Order_Normal.getEntry(c, pOrd);

		//assigning it to a normal cook

		int n = 0;
		while (n < AV_Cooks_Normal.getLength() && found == false)
		{
			AV_Cooks_Normal.getEntry(n, pCook);
			found = assignCook(pCook.getData(), pOrd, timeStep);
			n++;
		}


		//assigning it to a VIP cook if normal cook not found
		int v = 0;
		while (v < Av_cooks_VIP.getLength() && found == false)
		{
			Av_cooks_VIP.getEntry(v, pCook);
			found = assignCook(pCook.getData(), pOrd, timeStep);
			v++;
		}

		//if this order wasn't assigned for whatever reason, go to the next order
		if (found == false)
		{
			c++;
		}
		i++;

	}
}

void Restaurant::serviceUrgentOrder(int timeStep)
{
	while (W_Order_Urgent.isEmpty())
		return;

	int i = 0;
	int c = 0;
	W_Order_Urgent.toArray(c);

	while (i < c)
	{
		bool found = false;

		Order* pOrd;
		PriorityData<Cook*> pCook;
		W_Order_Urgent.peekFront(pOrd);

		//assigning it to a VIP cook
		int v = 0;
		while (v < Av_cooks_VIP.getLength() && found == false)
		{
			Av_cooks_VIP.getEntry(v, pCook);
			found = assignCook(pCook.getData(), pOrd, timeStep);
			v++;
		}


		//assigning it to a normal cook if VIP cook not found
		int n = 0;
		while (n < AV_Cooks_Normal.getLength() && found == false)
		{
			AV_Cooks_Normal.getEntry(n, pCook);
			found = assignCook(pCook.getData(), pOrd, timeStep);
			n++;
		}


		//assigning it to a vegan cook if neither VIP nor normal cook is found
		int g = 0;
		while (g < AV_Cooks_vegan.getLength() && found == false)
		{
			AV_Cooks_vegan.getEntry(g, pCook);
			found = assignCook(pCook.getData(), pOrd, timeStep);
			g++;
		}

		//if there are no available cooks we see if there are any on break cooks
		if (found == false)
		{
			found = cooksOnBreakAlternative(pOrd, timeStep);
		}

		//if found is still false meaning that there are no available cooks or on break then we take from rest if possible
		if (found == false)
		{
			found = cooksInRestAlternative(pOrd, timeStep);
		}

		i++;
	}

}

void Restaurant::servicedOrders(Order* order, int timeStep)
{
	if (order->GetType() == TYPE_VIP)
	{

		bool found1 = W_Order_VIP.remove(order);

		if (found1 == false) //if the order wasn't removed from waiting VIP orders then this means that this order is an urgent order (in the waiting urgent orders list)
		{
			W_Order_Urgent.dequeue(order);
		}

	}


	else if (order->GetType() == TYPE_NRM)
	{
		bool found2 = false;
		int i = 0;
		Order* pOrd;

		while (i < W_Order_Normal.getLength() && found2 == false)
		{
			W_Order_Normal.getEntry(i, pOrd);

			if (order->GetID() == pOrd->GetID())
			{
				W_Order_Normal.remove(i);
				found2 = true;
			}
			else
				i++;

		}
	}

	else if (order->GetType() == TYPE_VGAN)
	{
		W_Order_Vegan.dequeue(order);
	}


	order->setStatus(SRV);
	order->setWaitingTime(timeStep - order->getArrTime());
	In_service.insert(In_service.getLength(), order);

}

void Restaurant::FillDrawingList()
{

	//This function should be implemented in phase1
	//It should add ALL orders and Cooks to the drawing list
	//It should get orders from orders lists/queues/stacks/whatever (same for Cooks)
	//To add orders it should call function  void GUI::AddToDrawingList(Order* pOrd);
	//To add Cooks it should call function  void GUI::AddToDrawingList(Cook* pCc);

	Order*pOrd;
	Cook*pCc;
	int size = 999;
	Order** WN_Orders_Array = W_Order_Normal.toArray(size);
	for(int i=0; i<size; i++)
	{
		pOrd = WN_Orders_Array[i];
		pGUI->AddToDrawingList(pOrd);
	}

	Order** WV_Orders_Array = W_Order_Vegan.toArray(size);
	for(int i=0; i<size; i++)
	{
		pOrd = WV_Orders_Array[i];
		pGUI->AddToDrawingList(pOrd);
	}

	Order** WVIP_Orders_Array = W_Order_VIP.toArray(size); 
	for(int i=0; i<size; i++)
	{
		pOrd=WVIP_Orders_Array[i];
		pGUI->AddToDrawingList(pOrd);
	}
	
	Cook**Vip_Cook=Av_cooks_VIP.toArray(size);
	for(int i=0; i<size; i++)
	{
		pCc=Vip_Cook[i];
		pGUI->AddToDrawingList(pCc);
	}

	Cook**N_Cook=AV_Cooks_Normal.toArray(size);
	for(int i=0; i<size; i++)
	{
		pCc=N_Cook[i];
		pGUI->AddToDrawingList(pCc);
	}

	Cook**Ve_Cook=AV_Cooks_vegan.toArray(size);
	for(int i=0; i<size; i++)
	{
		pCc=Ve_Cook[i];
		pGUI->AddToDrawingList(pCc);
	}

	
	
}
	/*for(int i=0; i<size; i++)
	{
		pCc=N_Cook[i];
		pGUI->AddToDrawingList(pCc);
	}*/
	

void Restaurant::Simple_simulator()
{
	ifstream fofo;
	string filename;	
	//Order* pOrd;
	//Event* pEv;


	pGUI->PrintMessage("Simple simulator.  >=  I/P filename:");
	 
	fofo.open(pGUI->GetString());
	LoadingFunction(fofo);

	pGUI->PrintMessage("Events should be loaded from a file...CLICK to continue");
	pGUI->waitForClick();

	int CurrentTimeStep = 1;
	
	pGUI->UpdateInterface();
	//as long as events queue is not empty yet
	while(!EventsQueue.isEmpty() || !In_service.isEmpty() )
	{
		//print current timestep
		char timestep[100];
		itoa(CurrentTimeStep,timestep,100);	
		pGUI->PrintMessage(timestep);
		Order*poord;
		ExecuteEvents(CurrentTimeStep);
		//execute all events at current time step
		FillDrawingList();
		pGUI->UpdateInterface();
		pGUI->waitForClick();

		if(!W_Order_VIP.isEmpty())
			{
				W_Order_VIP.remove(poord);
				poord->setStatus(SRV);
				int size = In_service.getLength();
				In_service.insert(size, poord);

				pGUI->AddToDrawingList(poord);
			}

		if (!W_Order_Normal.isEmpty())
			{
				W_Order_Normal.getEntry(0,poord);
				W_Order_Normal.remove(0);
				poord->setStatus(SRV);
				int size = In_service.getLength();
				In_service.insert(size, poord);

				pGUI->AddToDrawingList(poord);

			}
		if(!W_Order_Vegan.isEmpty())
			{
				W_Order_Vegan.dequeue(poord);
				poord->setStatus(SRV);
				int size = In_service.getLength();
				In_service.insert(size, poord);
				
				pGUI->AddToDrawingList(poord);
			}
		
		/*//The next line may add new orders to the DEMO_Queue
		ExecuteEvents(CurrentTimeStep);	//execute all events at current time step
		FillDrawingList();
		pGUI->UpdateInterface();*/

		/////////////////////////////////////////////////////////////////////////////////////////
		/// The next code section should be done through function "FillDrawingList()" once you
		/// decide the appropriate list type for Orders and Cooks

	
		if (CurrentTimeStep % 5==0)
		{   
			if ( !In_service.isEmpty() )
			{
				for ( int i=0; i<3; i++ )
				{  if (!In_service.isEmpty() )
					{Order*pooord;
				    In_service.getEntry(0,pooord);
					In_service.remove(0);
					pooord->setStatus(DONE);
					finished.enqueue(pooord);
					pGUI->AddToDrawingList(pooord);
				}
				}
			}
		}
		
		pGUI->UpdateInterface();
			CurrentTimeStep++;
			pGUI->ResetDrawingList();
			int count;
			if(!finished.isEmpty() )
			{Order** poooord= finished.toArray(count);
			for(int i=0;i<count;i++)

			{
				pGUI->AddToDrawingList(poooord[i]);
			}
			}
			if(!In_service.isEmpty() )
			{Order** poooord=In_service.toArray(count);
			for(int i=0;i<count;i++)

			{
				pGUI->AddToDrawingList(poooord[i]);
			}
			}
		pGUI->waitForClick();
	}
	
	pGUI->PrintMessage("generation done, click to END program");
		pGUI->waitForClick();
	}




	//////////////////////////////////////////////////////////////////////////////////////////////
	/// ==> 
	///  DEMO-related functions. Should be removed in phases 1&2

	//Begin of DEMO-related functions

	//This is just a demo function for project introductory phase
	//It should be removed starting phase 1
	/**void Restaurant::Just_A_Demo()
	{

		//
		// THIS IS JUST A DEMO FUNCTION
		// IT SHOULD BE REMOVED IN PHASE 1 AND PHASE 2

		int EventCnt;	
		Order* pOrd;
		Event* pEv;
		srand(time(NULL));

		pGUI->PrintMessage("Just a Demo. Enter EVENTS Count(next phases should read I/P filename):");
		EventCnt = atoi(pGUI->GetString().c_str());	//get user input as a string then convert to integer

		pGUI->PrintMessage("Generating Events randomly... In next phases, Events should be loaded from a file...CLICK to continue");
		pGUI->waitForClick();

		//Just for sake of demo, generate some cooks and add them to the drawing list
		//In next phases, Cooks info should be loaded from input file
		int C_count = 12;	
		Cook *pC = new Cook[C_count];
		int cID = 1;

		for(int i=0; i<C_count; i++)
		{
			cID+= (rand()%15+1);	
			pC[i].setID(cID);
			pC[i].setType((ORD_TYPE)(rand()%TYPE_CNT));
		}	


		int EvTime = 0;

		int O_id = 1;

		//Create Random events and fill them into EventsQueue
		//All generated event will be "ArrivalEvents" for the demo
		for(int i=0; i<EventCnt; i++)
		{
			O_id += (rand()%4+1);		
			int OType = rand()%TYPE_CNT;	//Randomize order type		
			EvTime += (rand()%5+1);			//Randomize event time
			//pEv = new ArrivalEvent(EvTime,O_id,(ORD_TYPE)OType);
			EventsQueue.enqueue(pEv);

		}	

		// --->   In next phases, no random generation is done
		// --->       EventsQueue should be filled from actual events loaded from input file





		//Now We have filled EventsQueue (randomly)
		int CurrentTimeStep = 1;


		//as long as events queue is not empty yet
		while(!EventsQueue.isEmpty())
		{
			//print current timestep
			char timestep[10];
			itoa(CurrentTimeStep,timestep,10);	
			pGUI->PrintMessage(timestep);


			//The next line may add new orders to the DEMO_Queue
			ExecuteEvents(CurrentTimeStep);	//execute all events at current time step


			/////////////////////////////////////////////////////////////////////////////////////////
			/// The next code section should be done through function "FillDrawingList()" once you
			/// decide the appropriate list type for Orders and Cooks

			//Let's add ALL randomly generated Cooks to GUI::DrawingList
			for(int i=0; i<C_count; i++)
				pGUI->AddToDrawingList(&pC[i]);

			//Let's add ALL randomly generated Ordes to GUI::DrawingList
			int size = 0;
			Order** Demo_Orders_Array = DEMO_Queue.toArray(size);

			for(int i=0; i<size; i++)
			{
				pOrd = Demo_Orders_Array[i];
				pGUI->AddToDrawingList(pOrd);
			}
			/////////////////////////////////////////////////////////////////////////////////////////

			pGUI->UpdateInterface();
			Sleep(1000);
			CurrentTimeStep++;	//advance timestep
			pGUI->ResetDrawingList();
		}

		delete []pC;


		pGUI->PrintMessage("generation done, click to END program");
		pGUI->waitForClick();


	}**/
	////////////////

	/*void Restaurant::AddtoDemoQueue(Order *pOrd)
	{
		DEMO_Queue.enqueue(pOrd);
	}*/

	/// ==> end of DEMO-related function
	//////////////////////////////////////////////////////////////////////////////////////////////


